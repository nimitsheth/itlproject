import React from 'react'
import { UserButton } from '@clerk/clerk-react';

function User() {
  return (
    <UserButton />
  )
}

export default User