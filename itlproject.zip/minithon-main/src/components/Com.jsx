import React, { useRef } from 'react'
import Communities from './Communities'
import User from './User'
import ThemeToggle from './ThemeToggle'
import Navbar from './Navbar'

function Com() {
    const containerRef = useRef(null);
  return (
 
          
    
      <Communities/>


  )
}

export default Com